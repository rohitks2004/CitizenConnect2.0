// Solved.jsx
import React from 'react';
import { Link } from 'react-router-dom';

function Solved() {
  return (
    <>
      <h2>Solved</h2>
      <Link to="/home-Admin">Back to Home Admin</Link>
    </>
  );
}

export default Solved;
